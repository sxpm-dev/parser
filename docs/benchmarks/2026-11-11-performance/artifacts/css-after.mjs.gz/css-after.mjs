// packages/css/src/_generated/parser.ts
var RX0 = new RegExp("^(?:(?:--|[-_a-zA-Z\\u0080-\\uFFFF])(?:[-_a-zA-Z0-9\\u0080-\\uFFFF]|\\\\[^\\r\\n])*)$", "u");
var RX1 = new RegExp("^(?:--[-_a-zA-Z0-9\\u0080-\\uFFFF]+)$", "u");
var RX2 = new RegExp("^(?:(?![@$])[\\s\\S]+)$", "u");
var RX3 = new RegExp("^(?:@[-_a-zA-Z][\\s\\S]*)$", "u");
var RX4 = new RegExp("^(?:@[-_a-zA-Z][\\s\\S]*)$", "u");
function h0(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v) && Object.hasOwn(v, "property") && typeof v["property"] === "string" && Object.hasOwn(v, "value") && typeof v["value"] === "string" && Object.keys(v).length === 2;
}
function h2(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v) && Object.hasOwn(v, "selectors") && isList(v["selectors"]) && Object.hasOwn(v, "children") && isList(v["children"]) && Object.keys(v).length === 2;
}
function h3(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v) && Object.hasOwn(v, "prelude") && typeof v["prelude"] === "string" && Object.hasOwn(v, "children") && isList(v["children"]) && Object.keys(v).length === 2;
}
function h4(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v) && Object.hasOwn(v, "statement") && typeof v["statement"] === "string" && Object.keys(v).length === 1;
}
function h5(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v) && Object.hasOwn(v, "children") && isList(v["children"]) && Object.keys(v).length === 1;
}
function isList(v) {
  return Array.isArray(v) && Object.keys(v).length === v.length;
}
var Reader = class {
  constructor(s, target2, maxDepth = 256, verify = false) {
    this.s = s;
    this.pos = 0;
    this.far = 0;
    this.depth = 0;
    this.maxDepth = maxDepth;
    this.verify = verify;
    this.skippedAt = -1;
  }
  fail() {
    if (this.pos > this.far) this.far = this.pos;
    return void 0;
  }
  skip() {
    if (this.skippedAt === this.pos) return true;
    const s = this.s;
    for (; ; ) {
      while (this.pos < s.length) {
        const c2 = s.charCodeAt(this.pos);
        if (c2 !== 32 && (c2 < 9 || c2 > 13)) break;
        this.pos++;
      }
      const c = s.charCodeAt(this.pos);
      if (c === 47 && s.charCodeAt(this.pos + 1) === 42) {
        const end = s.indexOf("*/", this.pos + 2);
        if (end < 0) {
          this.pos = s.length;
          this.fail();
          return false;
        }
        this.pos = end + 2;
        continue;
      }
      this.skippedAt = this.pos;
      return true;
    }
  }
  literal(lit) {
    if (!this.skip()) return false;
    if (this.s.startsWith(lit, this.pos)) {
      this.pos += lit.length;
      return true;
    }
    this.fail();
    return false;
  }
  error() {
    const e = new SyntaxError("Unexpected input at offset " + Math.max(this.pos, this.far));
    e.offset = Math.max(this.pos, this.far);
    return e;
  }
  p0(expected) {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    const verify = this.verify;
    let matched = !verify || h0(expected);
    let result;
    parse: {
      const e0 = verify && matched ? expected["property"] : void 0;
      const v0 = this.s0();
      if (v0 === void 0) {
        break parse;
      }
      if (verify && v0 !== e0) matched = false;
      if (!this.literal(":")) {
        break parse;
      }
      const e1 = verify && matched ? expected["value"] : void 0;
      const v1 = this.s1();
      if (v1 === void 0) {
        break parse;
      }
      if (verify && v1 !== e1) matched = false;
      if (!this.literal(";") && !(this.pos === this.s.length || this.s.charCodeAt(this.pos) === 125)) {
        break parse;
      }
      if (verify) result = matched;
      else {
        result = { ["property"]: v0, ["value"]: v1 };
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p1(expected) {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    const verify = this.verify;
    let matched = !verify || h0(expected);
    let result;
    parse: {
      const e0 = verify && matched ? expected["property"] : void 0;
      const v0 = this.s2();
      if (v0 === void 0) {
        break parse;
      }
      if (verify && v0 !== e0) matched = false;
      if (!this.literal(":")) {
        break parse;
      }
      const e1 = verify && matched ? expected["value"] : void 0;
      const v1 = this.s3();
      if (v1 === void 0) {
        break parse;
      }
      if (verify && v1 !== e1) matched = false;
      if (!this.literal(";") && !(this.pos === this.s.length || this.s.charCodeAt(this.pos) === 125)) {
        break parse;
      }
      if (verify) result = matched;
      else {
        result = { ["property"]: v0, ["value"]: v1 };
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p2(expected) {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    const verify = this.verify;
    let matched = !verify || h2(expected);
    let result;
    parse: {
      const e0 = verify && matched ? expected["selectors"] : void 0;
      const v0 = verify ? void 0 : [];
      let n0 = 0;
      if (!this.skip()) {
        break parse;
      }
      if (!(this.pos === this.s.length || this.s.charCodeAt(this.pos) === 123)) {
        for (; ; ) {
          const child = this.s4();
          if (child === void 0) {
            break parse;
          }
          if (verify) {
            if (child !== e0?.[n0]) matched = false;
          } else v0.push(child);
          n0++;
          if (this.pos === this.s.length || this.s.charCodeAt(this.pos) === 123) break;
          if (!this.literal(",")) {
            break parse;
          }
        }
      }
      if (n0 < 1) {
        break parse;
      }
      if (verify && n0 !== e0?.length) matched = false;
      if (!this.literal("{")) {
        break parse;
      }
      const e1 = verify && matched ? expected["children"] : void 0;
      const v1 = verify ? void 0 : [];
      let n1 = 0;
      if (!this.skip()) {
        break parse;
      }
      while (!(this.pos === this.s.length || this.s.charCodeAt(this.pos) === 125)) {
        const before = this.pos;
        let child;
        if (child === void 0) child = this.p1(verify ? e1?.[n1] : void 0);
        if (child === void 0) child = this.p0(verify ? e1?.[n1] : void 0);
        if (child === void 0) child = this.p3(verify ? e1?.[n1] : void 0);
        if (child === void 0) child = this.p4(verify ? e1?.[n1] : void 0);
        if (child === void 0) child = this.p2(verify ? e1?.[n1] : void 0);
        if (child === void 0 || this.pos === before) {
          break parse;
        }
        if (verify) {
          if (child !== true) matched = false;
        } else v1.push(child);
        n1++;
        if (!this.skip()) {
          break parse;
        }
      }
      if (n1 < 0) {
        break parse;
      }
      if (verify && n1 !== e1?.length) matched = false;
      if (!this.literal("}")) {
        break parse;
      }
      if (verify) result = matched;
      else {
        result = { ["selectors"]: v0, ["children"]: v1 };
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p3(expected) {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    const verify = this.verify;
    let matched = !verify || h3(expected);
    let result;
    parse: {
      const e0 = verify && matched ? expected["prelude"] : void 0;
      const v0 = this.s5();
      if (v0 === void 0) {
        break parse;
      }
      if (verify && v0 !== e0) matched = false;
      if (!this.literal("{")) {
        break parse;
      }
      const e1 = verify && matched ? expected["children"] : void 0;
      const v1 = verify ? void 0 : [];
      let n1 = 0;
      if (!this.skip()) {
        break parse;
      }
      while (!(this.pos === this.s.length || this.s.charCodeAt(this.pos) === 125)) {
        const before = this.pos;
        let child;
        if (child === void 0) child = this.p1(verify ? e1?.[n1] : void 0);
        if (child === void 0) child = this.p0(verify ? e1?.[n1] : void 0);
        if (child === void 0) child = this.p3(verify ? e1?.[n1] : void 0);
        if (child === void 0) child = this.p4(verify ? e1?.[n1] : void 0);
        if (child === void 0) child = this.p2(verify ? e1?.[n1] : void 0);
        if (child === void 0 || this.pos === before) {
          break parse;
        }
        if (verify) {
          if (child !== true) matched = false;
        } else v1.push(child);
        n1++;
        if (!this.skip()) {
          break parse;
        }
      }
      if (n1 < 0) {
        break parse;
      }
      if (verify && n1 !== e1?.length) matched = false;
      if (!this.literal("}")) {
        break parse;
      }
      if (verify) result = matched;
      else {
        result = { ["prelude"]: v0, ["children"]: v1 };
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p4(expected) {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    const verify = this.verify;
    let matched = !verify || h4(expected);
    let result;
    parse: {
      const e0 = verify && matched ? expected["statement"] : void 0;
      const v0 = this.s6();
      if (v0 === void 0) {
        break parse;
      }
      if (verify && v0 !== e0) matched = false;
      if (!this.literal(";")) {
        break parse;
      }
      if (verify) result = matched;
      else {
        result = { ["statement"]: v0 };
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p5(expected) {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    const verify = this.verify;
    let matched = !verify || h5(expected);
    let result;
    parse: {
      const e0 = verify && matched ? expected["children"] : void 0;
      const v0 = verify ? void 0 : [];
      let n0 = 0;
      if (!this.skip()) {
        break parse;
      }
      while (!(this.pos === this.s.length || false)) {
        const before = this.pos;
        let child;
        if (child === void 0) child = this.p3(verify ? e0?.[n0] : void 0);
        if (child === void 0) child = this.p4(verify ? e0?.[n0] : void 0);
        if (child === void 0) child = this.p2(verify ? e0?.[n0] : void 0);
        if (child === void 0 || this.pos === before) {
          break parse;
        }
        if (verify) {
          if (child !== true) matched = false;
        } else v0.push(child);
        n0++;
        if (!this.skip()) {
          break parse;
        }
      }
      if (n0 < 0) {
        break parse;
      }
      if (verify && n0 !== e0?.length) matched = false;
      if (verify) result = matched;
      else {
        result = { ["children"]: v0 };
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  s0() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (!stack?.length) {
        if (c === 58) break;
        if (c === 59 || c === 123 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX0.test(value)) return this.fail();
    return value;
  }
  s1() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if ((c === 117 || c === 85) && ((s.charCodeAt(i + 1) === 114 || s.charCodeAt(i + 1) === 82) && ((s.charCodeAt(i + 2) === 108 || s.charCodeAt(i + 2) === 76) && s.charCodeAt(i + 3) === 40))) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 59 || c === 125) break;
        if (c === 123) {
          this.pos = i;
          return this.fail();
        }
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    return value;
  }
  s2() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    if (!s.startsWith("--", i)) return this.fail();
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (!stack?.length) {
        if (c === 58) break;
        if (c === 59 || c === 123 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX1.test(value)) return this.fail();
    return value;
  }
  s3() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if ((c === 117 || c === 85) && ((s.charCodeAt(i + 1) === 114 || s.charCodeAt(i + 1) === 82) && ((s.charCodeAt(i + 2) === 108 || s.charCodeAt(i + 2) === 76) && s.charCodeAt(i + 3) === 40))) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 59 || c === 125) break;
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    return value;
  }
  s4() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if ((c === 117 || c === 85) && ((s.charCodeAt(i + 1) === 114 || s.charCodeAt(i + 1) === 82) && ((s.charCodeAt(i + 2) === 108 || s.charCodeAt(i + 2) === 76) && s.charCodeAt(i + 3) === 40))) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 44 || c === 123) break;
        if (c === 59 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX2.test(value)) return this.fail();
    return value;
  }
  s5() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    if (!s.startsWith("@", i)) return this.fail();
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if ((c === 117 || c === 85) && ((s.charCodeAt(i + 1) === 114 || s.charCodeAt(i + 1) === 82) && ((s.charCodeAt(i + 2) === 108 || s.charCodeAt(i + 2) === 76) && s.charCodeAt(i + 3) === 40))) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 123) break;
        if (c === 59 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX3.test(value)) return this.fail();
    return value;
  }
  s6() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    if (!s.startsWith("@", i)) return this.fail();
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if ((c === 117 || c === 85) && ((s.charCodeAt(i + 1) === 114 || s.charCodeAt(i + 1) === 82) && ((s.charCodeAt(i + 2) === 108 || s.charCodeAt(i + 2) === 76) && s.charCodeAt(i + 3) === 40))) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 59) break;
        if (c === 123 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX4.test(value)) return this.fail();
    return value;
  }
};
function w0(v, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  if (!h0(v)) return void 0;
  const s0 = v["property"];
  const s1 = v["value"];
  return "" + s0 + ": " + s1 + ";";
}
function w2(v, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  if (!h2(v)) return void 0;
  if (v["selectors"].length < 1) return void 0;
  const a0 = [];
  for (const x of v["selectors"]) {
    if (typeof x !== "string") return void 0;
    a0.push(x);
  }
  const s0 = a0.join(", ");
  if (v["children"].length < 0) return void 0;
  const a1 = [];
  for (const x of v["children"]) {
    let s;
    if (s === void 0) s = w0(x, depth + 1);
    if (s === void 0) s = w3(x, depth + 1);
    if (s === void 0) s = w4(x, depth + 1);
    if (s === void 0) s = w2(x, depth + 1);
    if (s === void 0) return void 0;
    a1.push(s);
  }
  const s1 = a1.join("");
  return "" + s0 + " { " + s1 + " }";
}
function w3(v, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  if (!h3(v)) return void 0;
  const s0 = v["prelude"];
  if (v["children"].length < 0) return void 0;
  const a1 = [];
  for (const x of v["children"]) {
    let s;
    if (s === void 0) s = w0(x, depth + 1);
    if (s === void 0) s = w3(x, depth + 1);
    if (s === void 0) s = w4(x, depth + 1);
    if (s === void 0) s = w2(x, depth + 1);
    if (s === void 0) return void 0;
    a1.push(s);
  }
  const s1 = a1.join("");
  return "" + s0 + " { " + s1 + " }";
}
function w4(v, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  if (!h4(v)) return void 0;
  const s0 = v["statement"];
  return "" + s0 + ";";
}
function w5(v, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  if (!h5(v)) return void 0;
  if (v["children"].length < 0) return void 0;
  const a0 = [];
  for (const x of v["children"]) {
    let s;
    if (s === void 0) s = w3(x, depth + 1);
    if (s === void 0) s = w4(x, depth + 1);
    if (s === void 0) s = w2(x, depth + 1);
    if (s === void 0) return void 0;
    a0.push(s);
  }
  const s0 = a0.join("");
  return "" + s0;
}
function target(name) {
  switch (name) {
    case "object":
      return [name, false];
    case "json":
      return ["object", true];
    default:
      throw new TypeError("Unknown output " + name);
  }
}
function parse(input, options = {}) {
  if (typeof input !== "string") throw new TypeError("Input must be text");
  const [t, json] = target(options.output ?? "object");
  const max = options.maxDepth ?? 256;
  if (!Number.isInteger(max) || max < 1 || max > 512) throw new TypeError("maxDepth must be 1..512");
  const r = new Reader(input, t, max);
  const value = r.p5();
  if (value === void 0 || !r.skip() || r.pos !== input.length) throw r.error();
  return json ? JSON.stringify(value) : value;
}
function stringify(value, options = {}) {
  const name = options.input ?? "object";
  const [t, json] = target(name);
  if (json) {
    if (typeof value !== "string") throw new TypeError("Encoded input must be text");
    value = JSON.parse(value);
  }
  const source = w5(value, 0);
  if (source !== void 0) {
    const check = new Reader(source, t, 256, true);
    try {
      if (check.p5(value) === true && check.skip() && check.pos === source.length) return source;
    } catch {
    }
  }
  throw new TypeError("Value is not representable by this grammar");
}
function validate(input) {
  parse(input);
}
export {
  parse,
  stringify,
  validate
};
