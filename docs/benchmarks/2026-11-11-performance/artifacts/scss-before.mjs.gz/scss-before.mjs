// packages/scss/src/_generated/parser.ts
var RX0 = new RegExp("^(?:(?:[-_a-zA-Z\\u0080-\\uFFFF]|#\\{[\\s\\S]+\\})(?:[-_a-zA-Z0-9\\u0080-\\uFFFF]|#\\{[\\s\\S]+\\})*)$", "u");
var RX1 = new RegExp("^(?:--[-_a-zA-Z0-9\\u0080-\\uFFFF]+)$", "u");
var RX2 = new RegExp("^(?:(?![@$])[\\s\\S]+)$", "u");
var RX3 = new RegExp("^(?:@[-_a-zA-Z][\\s\\S]*)$", "u");
var RX4 = new RegExp("^(?:@[-_a-zA-Z][\\s\\S]*)$", "u");
var RX5 = new RegExp("^(?:[-_a-zA-Z][-_a-zA-Z0-9]*)$", "u");
var RX6 = new RegExp("^(?:\\$[-_a-zA-Z][-_a-zA-Z0-9]*)$", "u");
var COMMENTS = [["/*", "*/"], ["//", "\n"]];
function same(a, b) {
  if (a === b) return true;
  if (!a || !b || typeof a !== "object" || typeof b !== "object") return false;
  const ak = Object.keys(a), bk = Object.keys(b);
  return ak.length === bk.length && ak.every((k) => Object.hasOwn(b, k) && same(a[k], b[k]));
}
var Reader = class {
  constructor(s, target2, maxDepth = 256) {
    this.s = s;
    this.pos = 0;
    this.far = 0;
    this.target = target2;
    this.depth = 0;
    this.maxDepth = maxDepth;
  }
  fail() {
    if (this.pos > this.far) this.far = this.pos;
    return void 0;
  }
  skip() {
    const s = this.s;
    for (; ; ) {
      while (this.pos < s.length) {
        const c = s.charCodeAt(this.pos);
        if (c !== 32 && (c < 9 || c > 13)) break;
        this.pos++;
      }
      let found = false;
      for (const [open, close] of COMMENTS) {
        if (s.startsWith(open, this.pos)) {
          const end = s.indexOf(close, this.pos + open.length);
          if (end < 0) {
            if (close === "\n") {
              this.pos = s.length;
              return true;
            }
            this.pos = s.length;
            this.fail();
            return false;
          }
          this.pos = end + close.length;
          found = true;
          break;
        }
      }
      if (!found) return true;
    }
  }
  literal(lit) {
    if (!this.skip()) return false;
    if (this.s.startsWith(lit, this.pos)) {
      this.pos += lit.length;
      return true;
    }
    this.fail();
    return false;
  }
  boundary(stops) {
    return this.pos === this.s.length || stops.some((x) => this.s.startsWith(x, this.pos));
  }
  error() {
    const e = new SyntaxError("Unexpected input at offset " + Math.max(this.pos, this.far));
    e.offset = Math.max(this.pos, this.far);
    return e;
  }
  p0() {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    let result;
    parse: {
      const v0 = this.s0();
      if (v0 === void 0) {
        break parse;
      }
      if (!this.literal(":")) {
        break parse;
      }
      const v1 = this.s1();
      if (v1 === void 0) {
        break parse;
      }
      if (!this.literal(";") && !this.boundary(["}"])) {
        break parse;
      }
      switch (this.target) {
        case "object":
          result = { ["property"]: v0, ["value"]: v1 };
          break;
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p1() {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    let result;
    parse: {
      const v0 = this.s2();
      if (v0 === void 0) {
        break parse;
      }
      if (!this.literal(":")) {
        break parse;
      }
      const v1 = this.s3();
      if (v1 === void 0) {
        break parse;
      }
      if (!this.literal(";") && !this.boundary(["}"])) {
        break parse;
      }
      switch (this.target) {
        case "object":
          result = { ["property"]: v0, ["value"]: v1 };
          break;
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p2() {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    let result;
    parse: {
      const v0 = [];
      if (!this.skip()) {
        break parse;
      }
      if (!this.boundary(["{"])) {
        for (; ; ) {
          const child = this.s4();
          if (child === void 0) {
            break parse;
          }
          v0.push(child);
          if (this.boundary(["{"])) break;
          if (!this.literal(",")) {
            break parse;
          }
        }
      }
      if (v0.length < 1) {
        break parse;
      }
      if (!this.literal("{")) {
        break parse;
      }
      const v1 = [];
      if (!this.skip()) {
        break parse;
      }
      while (!this.boundary(["}"])) {
        const before = this.pos;
        let child;
        if (child === void 0) child = this.p7();
        if (child === void 0) child = this.p6();
        if (child === void 0) child = this.p1();
        if (child === void 0) child = this.p0();
        if (child === void 0) child = this.p3();
        if (child === void 0) child = this.p4();
        if (child === void 0) child = this.p2();
        if (child === void 0 || this.pos === before) {
          break parse;
        }
        v1.push(child);
        if (!this.skip()) {
          break parse;
        }
      }
      if (v1.length < 0) {
        break parse;
      }
      if (!this.literal("}")) {
        break parse;
      }
      switch (this.target) {
        case "object":
          result = { ["selectors"]: v0, ["children"]: v1 };
          break;
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p3() {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    let result;
    parse: {
      const v0 = this.s5();
      if (v0 === void 0) {
        break parse;
      }
      if (!this.literal("{")) {
        break parse;
      }
      const v1 = [];
      if (!this.skip()) {
        break parse;
      }
      while (!this.boundary(["}"])) {
        const before = this.pos;
        let child;
        if (child === void 0) child = this.p7();
        if (child === void 0) child = this.p6();
        if (child === void 0) child = this.p1();
        if (child === void 0) child = this.p0();
        if (child === void 0) child = this.p3();
        if (child === void 0) child = this.p4();
        if (child === void 0) child = this.p2();
        if (child === void 0 || this.pos === before) {
          break parse;
        }
        v1.push(child);
        if (!this.skip()) {
          break parse;
        }
      }
      if (v1.length < 0) {
        break parse;
      }
      if (!this.literal("}")) {
        break parse;
      }
      switch (this.target) {
        case "object":
          result = { ["prelude"]: v0, ["children"]: v1 };
          break;
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p4() {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    let result;
    parse: {
      const v0 = this.s6();
      if (v0 === void 0) {
        break parse;
      }
      if (!this.literal(";")) {
        break parse;
      }
      switch (this.target) {
        case "object":
          result = { ["statement"]: v0 };
          break;
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p5() {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    let result;
    parse: {
      const v0 = [];
      if (!this.skip()) {
        break parse;
      }
      while (!this.boundary([])) {
        const before = this.pos;
        let child;
        if (child === void 0) child = this.p7();
        if (child === void 0) child = this.p3();
        if (child === void 0) child = this.p4();
        if (child === void 0) child = this.p2();
        if (child === void 0 || this.pos === before) {
          break parse;
        }
        v0.push(child);
        if (!this.skip()) {
          break parse;
        }
      }
      if (v0.length < 0) {
        break parse;
      }
      switch (this.target) {
        case "object":
          result = { ["children"]: v0 };
          break;
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p6() {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    let result;
    parse: {
      const v0 = this.s7();
      if (v0 === void 0) {
        break parse;
      }
      if (!this.literal(":")) {
        break parse;
      }
      if (!this.literal("{")) {
        break parse;
      }
      const v1 = [];
      if (!this.skip()) {
        break parse;
      }
      while (!this.boundary(["}"])) {
        const before = this.pos;
        let child;
        if (child === void 0) child = this.p0();
        if (child === void 0) child = this.p6();
        if (child === void 0 || this.pos === before) {
          break parse;
        }
        v1.push(child);
        if (!this.skip()) {
          break parse;
        }
      }
      if (v1.length < 0) {
        break parse;
      }
      if (!this.literal("}")) {
        break parse;
      }
      switch (this.target) {
        case "object":
          result = { ["property"]: v0, ["children"]: v1 };
          break;
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  p7() {
    const start = this.pos;
    if (++this.depth > this.maxDepth) throw new SyntaxError("Maximum nesting exceeded");
    let result;
    parse: {
      const v0 = this.s8();
      if (v0 === void 0) {
        break parse;
      }
      if (!this.literal(":")) {
        break parse;
      }
      const v1 = this.s9();
      if (v1 === void 0) {
        break parse;
      }
      if (!this.literal(";") && !this.boundary(["}"])) {
        break parse;
      }
      switch (this.target) {
        case "object":
          result = { ["variable"]: v0, ["value"]: v1 };
          break;
      }
    }
    this.depth--;
    if (result === void 0) {
      this.fail();
      this.pos = start;
    }
    return result;
  }
  s0() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 117 && s.startsWith("url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("urL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("Url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("UrL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("//", i))) {
        const end = s.indexOf("\n", i + 2);
        i = end < 0 ? s.length : end + 1;
        continue;
      }
      if (c === 35 && s.startsWith("#{", i)) {
        (stack ??= []).push(125);
        i += 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 58) break;
        if (c === 59 || c === 123 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX0.test(value)) return this.fail();
    return value;
  }
  s1() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 117 && s.startsWith("url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("urL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("Url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("UrL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("//", i))) {
        const end = s.indexOf("\n", i + 2);
        i = end < 0 ? s.length : end + 1;
        continue;
      }
      if (c === 35 && s.startsWith("#{", i)) {
        (stack ??= []).push(125);
        i += 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 59 || c === 125) break;
        if (c === 123) {
          this.pos = i;
          return this.fail();
        }
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    return value;
  }
  s2() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    if (!s.startsWith("--", i)) return this.fail();
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (!stack?.length) {
        if (c === 58) break;
        if (c === 59 || c === 123 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX1.test(value)) return this.fail();
    return value;
  }
  s3() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 117 && s.startsWith("url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("urL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("Url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("UrL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("//", i))) {
        const end = s.indexOf("\n", i + 2);
        i = end < 0 ? s.length : end + 1;
        continue;
      }
      if (c === 35 && s.startsWith("#{", i)) {
        (stack ??= []).push(125);
        i += 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 59 || c === 125) break;
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    return value;
  }
  s4() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 117 && s.startsWith("url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("urL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("Url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("UrL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("//", i))) {
        const end = s.indexOf("\n", i + 2);
        i = end < 0 ? s.length : end + 1;
        continue;
      }
      if (c === 35 && s.startsWith("#{", i)) {
        (stack ??= []).push(125);
        i += 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 44 || c === 123) break;
        if (c === 59 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX2.test(value)) return this.fail();
    return value;
  }
  s5() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    if (!s.startsWith("@", i)) return this.fail();
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 117 && s.startsWith("url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("urL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("Url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("UrL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("//", i))) {
        const end = s.indexOf("\n", i + 2);
        i = end < 0 ? s.length : end + 1;
        continue;
      }
      if (c === 35 && s.startsWith("#{", i)) {
        (stack ??= []).push(125);
        i += 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 123) break;
        if (c === 59 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX3.test(value)) return this.fail();
    return value;
  }
  s6() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    if (!s.startsWith("@", i)) return this.fail();
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 117 && s.startsWith("url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("urL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("Url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("UrL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("//", i))) {
        const end = s.indexOf("\n", i + 2);
        i = end < 0 ? s.length : end + 1;
        continue;
      }
      if (c === 35 && s.startsWith("#{", i)) {
        (stack ??= []).push(125);
        i += 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 59) break;
        if (c === 123 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX4.test(value)) return this.fail();
    return value;
  }
  s7() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (!stack?.length) {
        if (c === 58) break;
        if (c === 59 || c === 123 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX5.test(value)) return this.fail();
    return value;
  }
  s8() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    if (!s.startsWith("$", i)) return this.fail();
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (!stack?.length) {
        if (c === 58) break;
        if (c === 59 || c === 123 || c === 125) {
          this.pos = i;
          return this.fail();
        }
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    if (!RX6.test(value)) return this.fail();
    return value;
  }
  s9() {
    if (!this.skip()) return void 0;
    const s = this.s, start = this.pos;
    let i = start, stack, opaqueDepth = 0;
    outer: while (i < s.length) {
      const c = s.charCodeAt(i);
      if (c === 92) {
        i += 1;
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 34 || c === 39) {
        const quote = c;
        i++;
        while (i < s.length && s.charCodeAt(i) !== quote) {
          if (s.startsWith("\\", i)) i += 1;
          i++;
        }
        if (i >= s.length) {
          this.pos = i;
          return this.fail();
        }
        i++;
        continue;
      }
      if (c === 117 && s.startsWith("url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("urL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 117 && s.startsWith("uRL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("Url(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("UrL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URl(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (c === 85 && s.startsWith("URL(", i)) {
        (stack ??= []).push(41);
        opaqueDepth = stack.length;
        i += 4;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("/*", i))) {
        const end = s.indexOf("*/", i + 2);
        if (end < 0) {
          this.pos = s.length;
          return this.fail();
        }
        i = end + 2;
        continue;
      }
      if (!opaqueDepth && (c === 47 && s.startsWith("//", i))) {
        const end = s.indexOf("\n", i + 2);
        i = end < 0 ? s.length : end + 1;
        continue;
      }
      if (c === 35 && s.startsWith("#{", i)) {
        (stack ??= []).push(125);
        i += 2;
        continue;
      }
      if (!stack?.length) {
        if (c === 59 || c === 125) break;
        if (c === 123) {
          this.pos = i;
          return this.fail();
        }
      }
      switch (c) {
        case 40:
          (stack ??= []).push(41);
          i++;
          continue;
        case 91:
          (stack ??= []).push(93);
          i++;
          continue;
        case 123:
          (stack ??= []).push(125);
          i++;
          continue;
        case 41:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 93:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
        case 125:
          if (!stack || stack.pop() !== c) {
            this.pos = i;
            return this.fail();
          }
          if (opaqueDepth && stack.length < opaqueDepth) opaqueDepth = 0;
          i++;
          continue;
      }
      i++;
    }
    this.pos = i;
    if (stack?.length) return this.fail();
    const value = s.slice(start, i).trim();
    if (!value) return this.fail();
    return value;
  }
};
function w0(v, target2, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  switch (target2) {
    case "object": {
      if (!(v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === 2 && Object.hasOwn(v, "property") && typeof v["property"] === "string" && Object.hasOwn(v, "value") && typeof v["value"] === "string")) return void 0;
      const s0 = v["property"];
      const s1 = v["value"];
      return "" + s0 + ": " + s1 + ";";
    }
  }
  return void 0;
}
function w1(v, target2, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  switch (target2) {
    case "object": {
      if (!(v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === 2 && Object.hasOwn(v, "property") && typeof v["property"] === "string" && Object.hasOwn(v, "value") && typeof v["value"] === "string")) return void 0;
      const s0 = v["property"];
      const s1 = v["value"];
      return "" + s0 + ": " + s1 + ";";
    }
  }
  return void 0;
}
function w2(v, target2, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  switch (target2) {
    case "object": {
      if (!(v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === 2 && Object.hasOwn(v, "selectors") && Array.isArray(v["selectors"]) && Object.hasOwn(v, "children") && Array.isArray(v["children"]))) return void 0;
      if (v["selectors"].length < 1) return void 0;
      const a0 = [];
      for (const x of v["selectors"]) {
        if (typeof x !== "string") return void 0;
        a0.push(x);
      }
      const s0 = a0.join(", ");
      if (v["children"].length < 0) return void 0;
      const a1 = [];
      for (const x of v["children"]) {
        let s;
        if (s === void 0) s = w7(x, target2, depth + 1);
        if (s === void 0) s = w6(x, target2, depth + 1);
        if (s === void 0) s = w1(x, target2, depth + 1);
        if (s === void 0) s = w0(x, target2, depth + 1);
        if (s === void 0) s = w3(x, target2, depth + 1);
        if (s === void 0) s = w4(x, target2, depth + 1);
        if (s === void 0) s = w2(x, target2, depth + 1);
        if (s === void 0) return void 0;
        a1.push(s);
      }
      const s1 = a1.join("");
      return "" + s0 + " { " + s1 + " }";
    }
  }
  return void 0;
}
function w3(v, target2, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  switch (target2) {
    case "object": {
      if (!(v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === 2 && Object.hasOwn(v, "prelude") && typeof v["prelude"] === "string" && Object.hasOwn(v, "children") && Array.isArray(v["children"]))) return void 0;
      const s0 = v["prelude"];
      if (v["children"].length < 0) return void 0;
      const a1 = [];
      for (const x of v["children"]) {
        let s;
        if (s === void 0) s = w7(x, target2, depth + 1);
        if (s === void 0) s = w6(x, target2, depth + 1);
        if (s === void 0) s = w1(x, target2, depth + 1);
        if (s === void 0) s = w0(x, target2, depth + 1);
        if (s === void 0) s = w3(x, target2, depth + 1);
        if (s === void 0) s = w4(x, target2, depth + 1);
        if (s === void 0) s = w2(x, target2, depth + 1);
        if (s === void 0) return void 0;
        a1.push(s);
      }
      const s1 = a1.join("");
      return "" + s0 + " { " + s1 + " }";
    }
  }
  return void 0;
}
function w4(v, target2, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  switch (target2) {
    case "object": {
      if (!(v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === 1 && Object.hasOwn(v, "statement") && typeof v["statement"] === "string")) return void 0;
      const s0 = v["statement"];
      return "" + s0 + ";";
    }
  }
  return void 0;
}
function w5(v, target2, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  switch (target2) {
    case "object": {
      if (!(v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === 1 && Object.hasOwn(v, "children") && Array.isArray(v["children"]))) return void 0;
      if (v["children"].length < 0) return void 0;
      const a0 = [];
      for (const x of v["children"]) {
        let s;
        if (s === void 0) s = w7(x, target2, depth + 1);
        if (s === void 0) s = w3(x, target2, depth + 1);
        if (s === void 0) s = w4(x, target2, depth + 1);
        if (s === void 0) s = w2(x, target2, depth + 1);
        if (s === void 0) return void 0;
        a0.push(s);
      }
      const s0 = a0.join("");
      return "" + s0;
    }
  }
  return void 0;
}
function w6(v, target2, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  switch (target2) {
    case "object": {
      if (!(v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === 2 && Object.hasOwn(v, "property") && typeof v["property"] === "string" && Object.hasOwn(v, "children") && Array.isArray(v["children"]))) return void 0;
      const s0 = v["property"];
      if (v["children"].length < 0) return void 0;
      const a1 = [];
      for (const x of v["children"]) {
        let s;
        if (s === void 0) s = w0(x, target2, depth + 1);
        if (s === void 0) s = w6(x, target2, depth + 1);
        if (s === void 0) return void 0;
        a1.push(s);
      }
      const s1 = a1.join("");
      return "" + s0 + ": { " + s1 + " }";
    }
  }
  return void 0;
}
function w7(v, target2, depth) {
  if (depth > 256) throw new TypeError("Maximum nesting exceeded");
  switch (target2) {
    case "object": {
      if (!(v !== null && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === 2 && Object.hasOwn(v, "variable") && typeof v["variable"] === "string" && Object.hasOwn(v, "value") && typeof v["value"] === "string")) return void 0;
      const s0 = v["variable"];
      const s1 = v["value"];
      return "" + s0 + ": " + s1 + ";";
    }
  }
  return void 0;
}
function target(name) {
  switch (name) {
    case "object":
      return [name, false];
    case "json":
      return ["object", true];
    default:
      throw new TypeError("Unknown output " + name);
  }
}
function parse(input, options = {}) {
  if (typeof input !== "string") throw new TypeError("Input must be text");
  const [t, json] = target(options.output ?? "object");
  const max = options.maxDepth ?? 256;
  if (!Number.isInteger(max) || max < 1 || max > 512) throw new TypeError("maxDepth must be 1..512");
  const r = new Reader(input, t, max);
  const value = r.p5();
  if (value === void 0 || !r.skip() || r.pos !== input.length) throw r.error();
  return json ? JSON.stringify(value) : value;
}
function stringify(value, options = {}) {
  const name = options.input ?? "object";
  const [t, json] = target(name);
  if (json) {
    if (typeof value !== "string") throw new TypeError("Encoded input must be text");
    value = JSON.parse(value);
  }
  const source = w5(value, t, 0);
  if (source === void 0) throw new TypeError("Value does not match a representable output");
  let parsed;
  try {
    parsed = parse(source, { output: t });
  } catch {
    throw new TypeError("Value is not representable by this grammar");
  }
  if (!same(parsed, value)) throw new TypeError("Value cannot round-trip through this grammar");
  return source;
}
function validate(input) {
  parse(input);
}
export {
  parse,
  stringify,
  validate
};
